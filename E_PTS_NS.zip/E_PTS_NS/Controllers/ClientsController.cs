﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.Net;

using E_PTS_NS.Service.DTOs;
using E_PTS_NS.Service.Interface;

namespace E_PTS_NS.WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ClientsController : Controller
    {
        private readonly IClientsService _clientService;
        public ClientsController(IClientsService clientsService)
        {
            _clientService = clientsService;
        }

        [HttpGet]
        [Route("GetAllClients")]
        public IEnumerable<ClientsDTO> GetStudents()
        {
            var clients = _clientService.GetClients();

            return clients;
        }

        [HttpGet]
        [Route("GetClientById")]
        public IActionResult GetStudentById(int id)
        {
            ClientsDTO clients = _clientService.GetClintsById(id);

            if (clients == null)
            {
                return NotFound("Clients with that id does not exist!");
            }

            return Ok(clients);
        }

        [HttpPost]
        [Route("AddClient")]
        public IActionResult Post([FromBody] ClientsDTO client)
        {
            if (ModelState.IsValid)
            {
                var newStudent = _clientService.AddClient(client);
                return Created($"Student with is {newClient.Id} has been created!", newClient.Id);
            }

            return UnprocessableEntity(ModelState);
        }

        [HttpPut]
        [Route("UpdateClient/{id:int}")]
        public IActionResult Put([FromRoute] int id, [FromBody] ClientsDTO client)
        {
            if (ModelState.IsValid)
            {
                client.Id = id;
                var result = _clientService.UpdateStudent(client);

                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    return NoContent();
                }
            }

            return BadRequest();
        }

        [HttpDelete("RemoveClient/{id:int}")]
        public IActionResult Delete([FromRoute] int id)
        {
            if (ModelState.IsValid)
            {
                return Ok(_clientService.DeleteClient(id));
            }

            return BadRequest();
        }
    }
}