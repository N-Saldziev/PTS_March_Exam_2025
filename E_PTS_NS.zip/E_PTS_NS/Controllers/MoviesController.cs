﻿using Microsoft.AspNetCore.Mvc;

namespace E_PTS_NS.WebAPI.Controllers
{
    public class MoviesController : Controller
    {
        [ApiController]
        [Route("[controller]")]
        public class MoviesController : ControllerBase
        {
            private readonly IMoviesService _movieService;
            private readonly ILogger<MoviesController> _logger;

            public MoviesController(IMoviesService moviesService, ILogger<MoviesController> logger)
            {
                _movieService = moviesService;
                _logger = logger;
            }

            [HttpGet]
            [Route("GetAllMovieses")]
            public IEnumerable<MoviesDTO> GetAddresses()
            {
                var movieses = _movieService.GetAddresses();

                return movieses;
            }

            [HttpGet]
            [Route("GetAddressById")]
            public IActionResult GetAddressById(int id)
            {
                MoviesDTO Movies = _movieService.GetMoviesById(id);

                if (Movies == null)
                {
                    return NotFound("Movie with that id does not exist!");
                }

                return Ok(Movies);
            }
        }
    }
