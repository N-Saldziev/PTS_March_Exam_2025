﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E_PTS_NS.Service.DTOs;

namespace E_PTS_NS.Service.Interface
{
    interface IMoviesService
    {
        List<MoviesDTO> GetMovies();

        MoviesDTO GetMovieById(int id);

    }
}
