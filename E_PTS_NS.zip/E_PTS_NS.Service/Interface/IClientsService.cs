﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E_PTS_NS.Service.DTOs;

namespace E_PTS_NS.Service.Interface
{
    interface IClientsService
    {
        List<ClientsDTO> GetClients();

        ClientsDTO GetClientById(int id);

        ClientsDTO AddClient(ClientsDTO clientDTO);

        ClientsDTO UpdateClient(ClientsDTO clientDTO);

        bool DeleteClient(int id);
    }
}
