﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_PTS_NS.Service.DTOs
{
    class ClientsDTO
    {
        public int Id { get; set; }

        public string FN { get; set; }

        public string LN { get; set; }

        public DateTime? DOB { get; set; }

        public string Address { get; set; }
        public int MCN { get; set; }
        public DateTime? MCVD { get; set; }
        public DateTime? RentDate { get; set; }
        public DateTime? ReturnDate { get; set; }

        //public virtual AddressDTO? Address { get; set; }
    }
}