﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using E_PTS_NS.Data.Entity;
using E_PTS_NS.Data.Interface;

namespace E_PTS_NS.Data.Repository
{
    class MovieRepository
    {
        private readonly MovieDataContext _dataContext;

        public MovieRepository(MoviesDataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public Movies GetAddressById(int id)
        {
            return _dataContext.Movieses.FirstOrDefault(x => x.Id == id);
        }

        public IEnumerable<Movies> GetAddresses()
        {
            return _dataContext.Movieses.ToList();
        }
    }
}
