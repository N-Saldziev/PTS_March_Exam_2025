﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E_PTS_NS.Data.Entity;
using E_PTS_NS.Data.Interface;

namespace E_PTS_NS.Data.Repository
{
    class ClientRepository : IClientsR
    {
        private readonly ClientDataContext _dataContext;

        public ClientRepository(ClientDataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public void AddClient(Clients client)
        {
            _dataContext.Clients.Add(client);
            _dataContext.SaveChanges();
        }

        public bool DeleteClient(Clients client)
        {
            try
            {
                _dataContext.Clients.Remove(client);
                _dataContext.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public Clients GetClientById(int id)
        {
            return _dataContext.Students.Include(s => s.Movies).FirstOrDefault(x => x.Id == id);
        }

        public IEnumerable<Clients> GetClients()
        {
            return _dataContext.Clients.Include(s => s.Movies);
        }

        public void UpdateStudent(Clients oldClient, Clients newClient)
        {
            _dataContext.Entry(oldClient).CurrentValues.SetValues(newClient);
            _dataContext.SaveChanges();
        }
    }
}