﻿using E_PTS_NS.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_PTS_NS.Data.Interface
{
    interface IMoviesR
    {
        IEnumerable<Movies> GetMopvies();

        Clients GetMoviesById(int id);
    }
}
