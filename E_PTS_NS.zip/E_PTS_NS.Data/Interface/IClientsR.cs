﻿using E_PTS_NS.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace E_PTS_NS.Data.Interface
{
    public interface IClientsR
    {
        IEnumerable<Clients> GetClients();

        Clients GetClientById(int id);

        void AddClients(Clients clients);

        void UpdateClient(Clients oldClient, Clients newClient);

        bool DeleteClient(Clients client);
    }
}


//namespace UniversityApplication.Data.Interfaces
//{
//    public interface IAddressRepository
//    {
//        IEnumerable<Address> GetAddresses();

//        Address GetAddressById(int id);

//    }
//}

//namespace UniversityApplication.Data.Interfaces
//{
//    public interface IStudentRepository
//    {
//        IEnumerable<Student> GetStudents();

//        Student GetStudentById(int id);

//        void AddStudent(Student student);

//        void UpdateStudent(Student oldStudent, Student newStudent);

//        bool DeleteStudent(Student student);
//    }
//}